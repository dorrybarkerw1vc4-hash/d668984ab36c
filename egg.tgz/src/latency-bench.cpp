// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("latency bench"); }
int main(){
  announce();
  return lionss_run_workload("latency-bench");
}
